
# Necessary frameowrks and module imports
from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
import pickle
from flask import *

app = Flask(__name__)

# Importing the machine learning algorithm
machine_learning_model_file = open("static/loan_prediction_ml_algorithm", "rb")

# Loading the machine learning model
machine_learning_model = pickle.load(machine_learning_model_file)
machine_learning_model_file.close()


@app.route('/', methods=["GET", "POST"])
def home_page():
    return render_template('index.html')

@app.route('/prediction-route', methods=["GET", "POST"])
def prediction_route():

    if request.method == "POST":

        loanamount = request.form['loanamount']
        if loanamount == "":
            pass

        else:
            userinput_dictionary = request.form
            gender = int(userinput_dictionary['gender'])
            married = int(userinput_dictionary['married'])
            education = int(userinput_dictionary['education'])
            selfemployed = int(userinput_dictionary['selfemployed'])
            applicantincome = float(userinput_dictionary['appincome'])
            coapplicantincome = float(userinput_dictionary['coappincome'])
            loanamount = float(userinput_dictionary['loanamount'])
            loanamountterm = int(userinput_dictionary['loanamountterm'])
            credithistory = int(userinput_dictionary['credithistory'])
            propertyarea = int(userinput_dictionary['propertyarea'])

            # Making the prediction on the basis of the values recieved by the user which he has inputted in the form
            prediction = machine_learning_model.predict([[gender, married, education, selfemployed, applicantincome, coapplicantincome, loanamount, loanamountterm, credithistory, propertyarea]])

            print('\n\n\n\nThis is the prediction value', prediction)

            if prediction == 1:
                value = 'The person is likely to get a loan'
                print('The person is likely to get a loan')
                return render_template('results.html', value=value)

            else:
                value = 'The person is not likely to get a loan'
                print('The person is not likely to get a loan')
                return render_template('results.html', value=value)

    return render_template('template1.html')

if __name__ == "__main__":
    app.run(debug=True, port=8000)
